#!/bin/bash
#java -jar -Dspring.profiles.active=server01 -Dspring.config.name=fileserver boot-fileserver-V0.0.1.jar     #--debug
fileserver_home=/home/fileserver/apps/web/boot-fileserver
while read line
do
    log_file=$fileserver_home"/logs/fileserver-$line.log"
    echo "nohup java -jar -Dspring.profiles.active=$line -Dspring.config.name=fileserver boot-fileserver-V0.0.1.jar >$log_file 2>&1 &"
    nohup java -jar -Dspring.profiles.active=$line -Dspring.config.name=fileserver boot-fileserver-V0.0.1.jar >$log_file 2>&1 &
done < servers
